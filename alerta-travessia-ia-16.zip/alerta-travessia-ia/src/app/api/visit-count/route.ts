import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";

/**
 * Contador de acessos — armazenado em arquivo (não em memória), porque a Hostinger
 * roda um processo Node.js persistente (diferente de plataformas serverless tipo
 * Vercel, onde o sistema de arquivos não sobrevive entre chamadas). Isso NÃO
 * funcionaria da mesma forma se o projeto voltasse a rodar no Vercel — lá seria
 * necessário um banco de dados de verdade (ex. Firebase, já usado em outras partes
 * do projeto).
 *
 * Simples de propósito: um número só, sem distinguir visitante único de recorrente.
 */

const COUNTER_FILE = path.join(process.cwd(), "data", "visit-count.json");

async function readCount(): Promise<number> {
  try {
    const raw = await fs.readFile(COUNTER_FILE, "utf-8");
    return JSON.parse(raw).count ?? 0;
  } catch {
    return 0; // arquivo ainda não existe (primeira vez)
  }
}

async function writeCount(count: number): Promise<void> {
  await fs.mkdir(path.dirname(COUNTER_FILE), { recursive: true });
  await fs.writeFile(COUNTER_FILE, JSON.stringify({ count }), "utf-8");
}

export async function GET() {
  const count = await readCount();
  return NextResponse.json({ count });
}

export async function POST() {
  try {
    const current = await readCount();
    const next = current + 1;
    await writeCount(next);
    return NextResponse.json({ count: next });
  } catch (err) {
    console.error("Falha ao gravar contador de acesso:", err);
    const current = await readCount().catch(() => 0);
    return NextResponse.json({ count: current });
  }
}
