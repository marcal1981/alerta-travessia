# Alerta Travessia IA

Plataforma de monitoramento e previsão probabilística de risco para a travessia de
balsa entre **São Sebastião** e **Ilhabela**.

> Esta previsão possui caráter informativo e não substitui os comunicados oficiais.
> A decisão sobre a operação da travessia é sempre da operadora responsável — o
> Índice de Risco da Travessia (IRT) nunca deve ser confundido com o Status Oficial.

## O que este projeto entrega (Fase 1)

Esta é uma **Fase 1 real e funcional**, não um mockup estático: o app roda, calcula
o índice de risco a partir de leituras meteorológicas, projeta 4 horizontes de
previsão, e tem um painel administrativo com pesos de algoritmo ajustáveis.

O que **não** é real ainda, por decisão deliberada (para não fingir uma integração
que não existe):

| Módulo | Status na Fase 1 | Para virar real |
|---|---|---|
| Leituras meteorológicas | **Real**, via Open-Meteo (`src/services/providers/openMeteoProvider.ts`) — combina a Forecast API (temperatura, pressão, umidade, vento, chuva, visibilidade) e a Marine API (altura/período de onda). Sem chave de API. Cai para dado simulado automaticamente se a chamada falhar. | Adicionar outros provedores (INMET, StormGlass, NOAA) seguindo o mesmo padrão de `WeatherProvider` |
| Maré | **Real**, edição 2026 (Marinha/CHM), cobrindo 21-27 de julho de 2026 | Extrair os demais meses do mesmo PDF pra cobrir o ano inteiro |
| Status Oficial da travessia | Atualização manual (em memória) | Ligar a uma API oficial da operadora/porto em `src/services/officialStatusService.ts` |
| Histórico | Array em memória | Firestore, quando `.env.local` tiver as credenciais (ver `.env.example`) |
| Autenticação / Usuários / Logs do Admin | Não implementado | Firebase Auth + Firestore |
| Notificações (Push/WhatsApp/Telegram/Email) | Não implementado | Cloud Messaging + integrações de mensageria |
| Radar, ondas, nuvens, chuva no mapa | Placeholders desabilitados no `MapPanel` | Provedores de tile externos (ex. RainViewer, Windy Map API) |
| PWA completo (ícones, service worker) | `manifest.json` mínimo | Gerar ícones e adicionar `next-pwa`/Workbox |

Essa tabela é o contrato: qualquer pessoa (ou eu, numa próxima sessão) sabe exatamente
o que trocar e onde, sem precisar reler todo o código.

## Por que a arquitetura foi feita assim

O ponto central do produto é a separação entre duas coisas que o brief pede para
**nunca misturar**:

1. **Status Oficial** (`officialStatusService.ts`) — fato, definido por humano/API oficial.
2. **MPT / Índice de Risco** (`riskEngine.ts`) — estimativa probabilística de IA.

Por isso são dois serviços independentes, com tipos diferentes (`OfficialStatus` vs
`MptResult`), e a UI (`StatusPanel` vs `RiskGauge`/`AIExplanation`) os renderiza em
componentes visualmente distintos, nunca fundidos num único número.

O motor de risco (`computeRiskIndex`) é uma combinação ponderada e **explicável**
(não uma caixa-preta): cada peso é editável no Admin, e `extractRiskFactors` sempre
consegue apontar qual variável mais empurrou o índice — é isso que alimenta a frase
gerada em `AIExplanation` ("O risco foi classificado como... principalmente devido a...").

## Nevoeiro como sinal categórico

O Departamento Hidroviário (DH), órgão que opera a travessia, divulgou publicamente que
cerca de **90% das paralisações recentes foram causadas por neblina/nevoeiro** — não por
vento ou ondas, que costumam ser o que se imagina primeiro. Por isso, o MPT não trata
nevoeiro como só "visibilidade baixa contínua": ele lê o código de tempo (WMO) que o
Open-Meteo já retorna, identifica os códigos 45/48 (nevoeiro) e aplica um peso extra
(`fogBoost`, editável no Admin) especificamente para esse sinal categórico. Isso está em
`src/services/providers/openMeteoProvider.ts` (leitura do `weather_code`) e
`src/services/riskEngine.ts` (uso do `isFog` no cálculo e como fator explicado ao usuário).

## Maré — cálculo local, sem API

A maré é 100% previsível astronomicamente: uma vez com a tábua oficial da Marinha
(CHM) para o ano corrente, não é preciso chamar API nenhuma pra "saber a maré agora" —
é só interpolação matemática sobre uma tabela (`src/services/tideService.ts`).

Existe uma regra oficial usada pela operadora da travessia: **caminhões de 3+ eixos
são proibidos de embarcar quando a maré cai abaixo de 0,5m** (rampas ficam íngremes
demais). Isso está codificado em `LOW_TIDE_TRUCK_RESTRICTION_M` (`src/types/index.ts`)
e aparece como aviso destacado no Painel Meteorológico quando ativo.

**Estado atual dos dados:** `src/data/sampleTideExtremes.ts` contém dados **reais** da
edição 2026 da tábua oficial (Marinha/CHM), extraídos por coordenadas de texto do PDF
(não por leitura visual, pra evitar erro de dígito) — mas cobrindo apenas 21 a 27 de
julho de 2026. Fora dessa janela, `tideM` volta a ser `null`. Para cobrir o ano inteiro,
repetir o mesmo processo de extração pros demais meses do mesmo PDF e anexar os pontos
ao array, no mesmo formato.

Fora do intervalo coberto pelos dados carregados, `tideM` permanece `null` — o app
nunca inventa um valor de maré.

## Janela de Embarque para Caminhões (`/caminhoes`)

Funcionalidade B2B pra transportadoras: mostra, por categoria de veículo (leve, VUC/toco,
3 eixos, 4+ eixos) e por sentido, se o embarque está liberado agora — combinando a
**Resolução Semil nº 79/2023** (horários fixos por categoria/dia/sentido) com a
**maré medida em tempo real** (regra dos 0,5m).

Isso é deliberadamente um serviço separado do MPT (`truckRestrictionService.ts`, não
`riskEngine.ts`): é uma regra determinística da lei, não uma estimativa de IA — misturar
os dois seria enganoso.

**Limitação documentada:** a resolução também estende os horários de restrição em
vésperas de feriado prolongado e no primeiro dia útil após — isso exige um calendário
de feriados nacionais/estaduais que ainda não está implementado (ver `TODO` no final de
`truckRestrictionService.ts`). Fora de feriados, a regra semanal está completa e testada.

## Câmeras e Tempo de Espera Oficiais

O Dashboard mostra as 9 câmeras oficiais do Departamento Hidroviário (5 em São
Sebastião, 4 em Ilhabela) e o tempo de espera publicado por eles, direto da
infraestrutura própria do governo (`dhapp3.azurewebsites.net`) — não usa nenhum proxy
de terceiro.

**Como funciona:** as câmeras são `<img>` simples (URLs oficiais, sem necessidade de
CORS). Já o tempo de espera não tem API JSON documentada — `src/app/api/dh-status/route.ts`
é uma rota de servidor que busca a página oficial (`semil.sp.gov.br/travessias/...`) e
extrai o texto "Tempo de Espera X minutos" por regex. Isso roda no servidor (não no
navegador do usuário) especificamente pra evitar bloqueio de CORS.

**Limitação documentada, não escondida:** por não ser uma API oficial e sim leitura de
HTML público, se o Departamento Hidroviário mudar o layout do site, essa extração pode
parar de funcionar silenciosamente até ser ajustada — por isso a rota sempre retorna
`null`s em vez de quebrar o Dashboard quando falha. O próprio site já mostrou um aviso
de "sistema instável" durante o desenvolvimento — esse aviso é repassado ao usuário
quando presente.

**Recomendação pra próxima fase:** ao propor a solução pro governo, pedir acesso oficial
a um endpoint estável (JSON) pra fila e câmeras é um pedido concreto e razoável — muito
mais sustentável que depender de scraping de HTML.

## Alerta Antecipado — Monitor Regional (Santos, Paraty, Oceano)

O IRT "Agora" continua 100% baseado em medição local do canal — isso nunca muda. Mas
os horizontes futuros de previsão (1h/2h/3h/5h) podem ser reforçados quando
`regionalWatchService.ts` detecta chuva forte, vento forte ou mar agitado em 3 pontos
de referência, cada um cobrindo um vetor físico diferente:

- **Santos** (SO, ~97km, confiança alta): frentes frias nesta costa se deslocam de
  Sul/Sudoeste para Nordeste — padrão climatológico bem documentado.
- **Paraty** (NE, ~95km, confiança **baixa**, marcado explicitamente na UI): a mesma
  faixa de litoral costuma ficar instável junto com São Sebastião/Ilhabela, mas não
  necessariamente por um sistema "viajando" de um pro outro — é mais um sinal de "a
  região toda está instável" do que uma previsão direcional confiável.
- **Ponto oceânico** (L, ~100km em alto-mar, confiança alta): ciclones extratropicais
  se formam no próprio oceano e avançam pra costa perpendicular a ela — fenômeno real
  e documentado (a Marinha do Brasil tem um serviço oficial só pra isso). Detectado por
  vento forte + onda alta no ponto (Marine API), não por chuva.

O reforço cresce gradualmente até o ETA estimado (distância ÷ velocidade do vento) —
nunca afeta o horizonte "Agora". Deliberadamente **não** se aplica a nevoeiro: neblina
se forma localmente, não se desloca como uma célula de chuva.

**Coleta de histórico (Etapa 1 da auto-calibração):** todo alerta detectado é registrado
em `firebase/firestore.ts` (`logRegionalAlert`), visível no Admin. Ainda **não** há
ajuste automático de confiança — com histórico zerado, isso seria só ruído estatístico.
A Etapa 2 (comparar o que foi previsto com o que realmente aconteceu, e recalibrar a
confiança de cada ponto com base na taxa de acerto real) só faz sentido depois de meses
de dado acumulado, e precisa do Firebase configurado de verdade — sem isso, o log se
perde a cada recarregamento.

## Layout do Dashboard (revisão)

- Mapa removido — a versão anterior não tinha função clara além de mostrar 2 pontos
  fixos, e os 4 botões de camadas (Radar/Ondas/Nuvens/Chuva) nunca chegaram a funcionar.
  Pode voltar numa Fase futura com uma função concreta (ex. mostrar a localização de
  cada câmera no mapa).
- Tempo de espera oficial fundido no painel de Status Oficial, com texto grande —
  informação considerada de alta prioridade pelo usuário.
- Painel Meteorológico reposicionado para logo depois da Previsão.
- Legendas das câmeras (distância até a balsa) agora sempre visíveis, não só no hover.
- Cartões de previsão simplificados para 1h/2h/3h/5h (removidos "Agora" e "30 minutos",
  redundantes com o medidor de risco principal).

## Linha do Tempo Preditiva (substituiu os cartões de previsão)

O antigo painel de "Previsão" (cartões 1h/2h/3h/5h) foi substituído por um gráfico de
linha do tempo mostrando o **dia inteiro (00h-23h)**, com a previsão real de vento
hora a hora do Open-Meteo (`timelineForecastService.ts`) — não mais uma extrapolação
matemática da leitura atual. As faixas de cor sob a curva são baseadas no **valor**
do vento (não na posição no tempo), usando os mesmos limiares do resto do app,
incluindo o limiar oficial de fechamento confirmado (46km/h). Quando há uma janela
contínua de vento acima desse limiar, aparece um aviso destacado com o horário exato.

## Outras mudanças de layout

- Câmeras agora em coluna única, largura total (antes: grade 2x2).
- Aviso de "Estimativa de IA" no topo do Dashboard mais compacto.

## Mudanças recentes (rajada, eixo do gráfico, página inicial)

- **Gráfico agora mostra RAJADA, não vento sustentado.** O backtest contra os 7
  fechamentos reais mostrou que o vento sustentado costuma ficar bem abaixo dos
  limiares nos fechamentos de verdade — é a rajada que se comporta de forma
  consistente com o que realmente fecha a travessia. `findCriticalWindow()` em
  `timelineForecastService.ts` também foi ajustado para usar `windGustKmh`.
- Eixo Y do gráfico agora mostra a unidade ("Xkm" em vez de só "X"), com margem e
  largura ajustadas para não cortar o primeiro dígito em telas menores.
- **Página inicial removida.** O conteúdo do Dashboard agora é a própria raiz do site
  (`src/app/page.tsx`). `/dashboard` virou um redirecionamento simples para `/`, para
  não quebrar links/favoritos antigos. O componente `Hero.tsx` ficou sem uso (não foi
  apagado, só não é mais renderizado em nenhuma página).

## Validação de Acurácia de Antecedência

Testar "quão precisa é a previsão feita X horas antes" com nossos 7 fechamentos reais
esbarra numa limitação real do Open-Meteo: a API que reconstrói previsões passadas
(Single Runs API) só tem arquivo a partir de abril/2026 — só 1 dos nossos 7 eventos
(23/06/2026) é recente o suficiente pra testar. Um único caso não vale como validação
estatística — só uma conferência pontual (ver `teste-antecedencia.mjs`, script
standalone, mesma lógica dos outros scripts de análise histórica).

**A validação de verdade é prospectiva, não retroativa:** `forecastSnapshotService.ts`
captura um "retrato" da previsão horária do dia a cada hora (no máximo), guardado via
`logForecastSnapshot()` em `firebase/firestore.ts`. Depois de algumas semanas
acumuladas, dá pra comparar cada retrato com o que realmente aconteceu, medindo a
precisão em diferentes horas de antecedência — visível no Admin.

**Limitação honesta:** sem o Firebase configurado de verdade, esses retratos se perdem
a cada recarregamento de página — o código já está pronto, só falta a configuração
real (`src/firebase/config.ts`) pra essa coleta funcionar de forma útil ao longo do
tempo.

## Aquecimento Pré-Frontal (sinal repassado por velejador experiente)

Um velejador experiente (Danilo Casa) relatou que o fechamento por vento nesta
travessia tem origem quase exclusiva na chegada de frente fria vinda do Sul, e que a
temperatura sobe rapidamente nas ~12h antes da frente chegar — antes mesmo do vento
intensificar. Implementado em `regionalWatchService.ts` (`checkPreFrontalWarming()`):
mede a variação de temperatura no próprio canal nas últimas 12h (via `past_hours` do
Open-Meteo); se subir ≥2°C, sinaliza como alerta antecipado de alta confiança.

**Ainda não validado numericamente** contra os 7 fechamentos reais já mapeados — a
validação está no `analise-historica.mjs` (seção de temperatura), que precisa ser
rodado (rede bloqueada neste ambiente) antes de confiar cegamente neste sinal.

## Leva de mudanças (fonte, ícone, contador, balsas em operação)

- **Navbar:** nome "Alerta Travessia IA" com fonte maior; botão "Ver situação agora"
  menor; ícone trocado de onda para um barco (também usado no favicon, `icon.svg`).
- **Balsas em operação — bug real corrigido:** a página oficial usa número por
  EXTENSO ("quatro embarcações em operação"), não dígito — o regex antigo só procurava
  dígito, por isso nunca capturava nada. Corrigido em `api/dh-status/route.ts` com
  suporte a ambos os formatos. Agora exibido no `StatusPanel`, com nota explicando que
  menos balsas costuma significar fila maior mesmo sem mau tempo (confirmado com um
  caso real ao vivo: fila de 120min num dia com só 4 balsas rodando, sem vento forte
  nenhum envolvido).
- **Contador de acesso:** `api/visit-count/route.ts`, armazenado em arquivo
  (`data/visit-count.json`) — funciona porque a Hostinger roda um processo Node.js
  persistente, diferente de plataformas serverless (Vercel) onde isso não
  sobreviveria entre chamadas. Visível no Admin.

## Firebase — implementação real (não mais stub)

`firebase/firestore.ts` agora grava e lê do Firestore de verdade quando configurado
(antes, mesmo com `NEXT_PUBLIC_FIREBASE_*` preenchidas, o código sempre operava só em
memória — os comentários "Fase 2: gravar em Firestore" nunca tinham sido implementados).
Cobre as 3 coleções: `history`, `regional_alert_log`, `forecast_snapshots`.

**Passo a passo para ativar (ação do usuário, fora do código):**
1. Criar projeto em https://console.firebase.google.com
2. Ativar **Firestore Database** (modo produção, região `southamerica-east1` recomendada)
3. Em "Configurações do projeto" → "Geral" → "Seus apps" → adicionar um app Web,
   copiar as credenciais geradas
4. Preencher essas credenciais como variáveis de ambiente `NEXT_PUBLIC_FIREBASE_*`
   no ambiente da Hostinger (painel Node.js → variáveis de ambiente, não em `.env.local`
   se o deploy for direto por upload)
5. Configurar regras de segurança do Firestore (por padrão o Firestore bloqueia tudo)

## Correção de cache desatualizado (celular vs PC)

Caso real observado: depois de um deploy, o PC mostrava a versão nova mas o celular
continuava mostrando a antiga — mesmo em aba anônima e em redes diferentes (Wi-Fi e
dados móveis). Isso indicava um proxy/cache intermediário (não algo no navegador em
si) guardando a página pelo endereço exato. Corrigido em `next.config.js` com
`Cache-Control: no-store, must-revalidate` nas páginas (excluindo `/_next/static/*`,
onde cache longo é seguro e importante pra performance, já que os arquivos têm nome
único por versão).

## Correções de layout mobile + sobreposição de status parado

- **Botão "Ver situação agora" removido do header** — apontava pra própria página em
  que já se está (redundante desde que Home e Dashboard viraram a mesma página), e
  competia por espaço com o nome do logo no celular, causando quebra em 3 linhas.
- **Nome "Alerta Travessia IA"** com fonte responsiva (menor no celular, maior no
  desktop) — evita a quebra de linha.
- **Gráfico da Linha do Tempo:** fontes dos eixos e das linhas de referência reduzidas
  (11→9px), rótulo "Risco de Interrupção" encurtado para "Risco" dentro do gráfico
  (o nome completo continua no aviso acima) — corrige deformação em telas estreitas.
- **Sobreposição "travessia interrompida":** quando o tempo de espera oficial mostra
  0min nos DOIS lados simultaneamente, isso é tratado como sinal forte de travessia
  parada (observação prática, não confirmada em documento oficial — documentado como
  heurística revisável em `src/app/page.tsx`), sobrepondo o medidor de risco (que
  antes só considerava dado meteorológico e podia mostrar "Operando" com a travessia
  de fato parada).

## Ajustes de intervalo, consistência de status, e gráfico mobile (2ª rodada)

- **Atualização automática:** intervalo mudado de 1 minuto para 20 minutos, a pedido.
- **Status Oficial x Medidor de Risco — contradição corrigida:** o painel de Status
  Oficial é um valor manual (Admin), nunca atualizado sozinho — podia mostrar
  "Operando" ao mesmo tempo que o medidor já mostrava "Risco de Interrupção" via a
  sobreposição de tempo de espera zerado. Agora ambos os painéis aplicam a mesma
  sobreposição (`src/app/page.tsx`), sem alterar o valor real guardado no Admin.
- **Gráfico ainda espremido no celular — resolvido de vez:** os rótulos de texto
  ("Operando"/"Alerta"/"Risco de Interrupção") foram RETIRADOS de dentro do SVG (onde
  competiam por espaço com os próprios dados) e viraram uma legenda compacta comum
  (bolinha colorida + texto) acima do gráfico. Eixo X com menos marcações (`interval={3}`)
  e eixo Y sem sufixo "km" (a unidade já está no subtítulo).

## Recalibração do motor de risco (medidor x gráfico de rajadas)

**Problema real reportado:** o medidor de risco central podia mostrar "risco baixo"
no mesmo momento em que o gráfico de Linha do Tempo já mostrava "Risco de
Interrupção" para a mesma rajada de vento — porque o medidor calculava uma MÉDIA
PONDERADA de vários fatores (vento, onda, maré...), diluindo o peso da rajada, que já
validamos ser a causa dominante real nos 7 fechamentos mapeados.

**Correção estrutural** em `riskEngine.ts`: em vez de uma média onde nenhum fator
sozinho pode superar seu próprio peso, agora a rajada é a BASE dominante (80% do
cálculo, numa escala já alinhada aos limiares reais 20/35/46km/h — a mesma usada no
gráfico), com fatores secundários (vento sustentado, onda, visibilidade, chuva)
ajustando só os 20% restantes. Nevoeiro e alerta oficial continuam como reforços
somados diretamente por cima, capazes de elevar o índice sozinhos.

**Validado com 4 cenários antes de aplicar:**
- Dia calmo (rajada 15km/h) → 15 (Baixo) ✓
- Rajada exatamente no limiar crítico real (46km/h) → 80 (Alto — já mostra "Risco de
  Interrupção", igual ao gráfico) ✓
- Rajada severa (70km/h, tipo o evento de 24/08/2025) → 85 (Muito Alto) ✓
- Nevoeiro sozinho, vento calmo → 41 (Atenção, mesmo sem vento nenhum)

## Rodando localmente

```bash
npm install
cp .env.example .env.local   # opcional na Fase 1 — o app roda sem isso, com dados simulados
npm run dev
```

Abra `http://localhost:3000` para a Home, `/dashboard` para o painel principal e
`/admin` para o painel administrativo.

## Estrutura de pastas

```
src/
  app/            # rotas (Next.js App Router): home, /dashboard, /admin
  components/     # UI: Hero, RiskGauge, StatusPanel, ForecastCards, WeatherPanel, MapPanel, AIExplanation
  services/       # weatherService, riskEngine (MPT), officialStatusService
  hooks/          # useCrossingRisk (polling + orquestração de estado)
  firebase/       # config.ts (stub) e firestore.ts (histórico)
  types/          # contrato de dados único, usado por serviços e componentes
  context/        # reservado para Fase 2 (ex. contexto de autenticação)
  utils/          # reservado para Fase 2
```

## Design

Tema escuro fixo (o brief pede dark theme como identidade, não como opção alternável).
Paleta: fundo azul-marinho profundo (`abyss`/`navy`), branco e cinza para texto/dados,
laranja e vermelho para os dois níveis mais altos de risco, e um acento ciano (`tide`)
para dados meteorológicos — inspirado no vocabulário visual de Windy/instrumentos
náuticos. O elemento de assinatura é o `RiskGauge`: um instrumento circular graduado
em 4 zonas com ponteiro animado, no espírito de um painel de bordo/aeronáutico,
porque é literalmente o que o brief pediu ("velocímetro animado") — só que tratado
como uma peça de design deliberada, não um componente genérico de biblioteca.

## Próximos passos sugeridos (Fase 2)

1. Escolher e implementar **um** provedor meteorológico real primeiro (Open-Meteo é o
   mais simples, sem chave de API) para validar o `MPT` com dado real.
2. Configurar o projeto Firebase e ligar `firestore.ts` + Firebase Auth.
3. Definir o processo de atualização do Status Oficial com a operadora da balsa.
4. Cloud Function agendada (Cloud Scheduler) rodando `runMpt` periodicamente e
   gravando no histórico, em vez do polling client-side atual.
5. Camadas de radar/ondas no mapa, cadastro de notificações, PWA completo.
