/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // PWA real (manifest + service worker) entra na Fase 2 via next-pwa ou Workbox.
  // Mantido simples aqui para nao acoplar a build a um pacote ainda nao instalado.

  // Evita que proxies/caches intermediários (operadora, provedor) guardem uma cópia
  // antiga das PÁGINAS — sem isso, celular e PC podem mostrar versões diferentes do
  // site por dias após um deploy, mesmo em aba anônima (caso real já observado).
  // Não afeta /_next/static/* (JS/CSS com nome único por versão — cache ali é seguro
  // e importante pra performance, por isso ficam de fora dessa regra).
  async headers() {
    return [
      {
        source: "/((?!_next/static).*)",
        headers: [
          { key: "Cache-Control", value: "no-store, must-revalidate" },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
