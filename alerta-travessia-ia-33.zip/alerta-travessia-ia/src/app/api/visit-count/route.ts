import { NextResponse } from "next/server";
import { incrementVisitCount, getVisitCount } from "@/firebase/firestore";

/**
 * Contador de acessos — agora vive no Firestore (ver `firebase/firestore.ts`), não
 * mais em arquivo local. Um usuário relatou o contador zerando após precisar apagar
 * toda a pasta do projeto na Hostinger durante uma investigação de cache; como o
 * Firestore vive fora dessa pasta, sobrevive a qualquer redeploy, mesmo "apagar tudo
 * e subir do zero". Sem Firebase configurado, cai para contagem em memória (reseta
 * a cada reinício do processo — mesmo comportamento já usado em outras partes do
 * projeto, como o histórico de alertas regionais).
 */

export async function GET() {
  const count = await getVisitCount();
  return NextResponse.json({ count });
}

export async function POST() {
  try {
    const count = await incrementVisitCount();
    return NextResponse.json({ count });
  } catch (err) {
    console.error("Falha ao incrementar contador de acesso:", err);
    const count = await getVisitCount().catch(() => 0);
    return NextResponse.json({ count });
  }
}
